# Hooks

Hooks are event-driven automations that run automatically during Codex or Claude Code sessions. Unlike skills (invoked manually) and rules (reference documents), hooks fire on lifecycle events — at session start or after a file is written or edited.

## Available Hooks

| Hook | Event | What it does |
|------|-------|-------------|
| [session-start-ambient](./session-start-ambient.sh) | Codex `SessionStart` | Adds compact Arch Studio routing context to root sessions without reading or writing state |
| [session-start-welcome](./session-start-welcome.sh) | First session after install | Displays a short `/as:studio` and `/as:learn` discovery notice, then records that it was emitted |
| [post-write-disclaimer-check](./post-write-disclaimer-check.sh) | After Write or Edit | Flags a regulatory output (zoning, occupancy, code analysis) that is missing the professional disclaimer |
| [version-check](./version-check.sh) | Enabled session startup, at most daily | Checks for a newer release and notifies once per version |

## Installation

None. Claude Code hooks ship via [`hooks.json`](./hooks.json); the Codex-only ambient hook ships via [`codex-hooks.json`](./codex-hooks.json). Both register with their respective plugin package when enabled.

```bash
claude plugin install as@skills-for-architects
```

Run `/hooks` in Claude Code to confirm they're loaded. Disable them by disabling the plugin, or per-session via `/hooks`.

> Versions ≤ 1.1.3 distributed these hooks as a `settings-snippet.json` requiring a manual merge into `~/.claude/settings.json`. If you did that merge, remove those entries — the plugin now registers the same hooks itself, and the old entries point at a path that no longer exists.

## Behavior

All three Claude Code hooks surface their output so Claude actually receives it (stderr with exit 0 is shown to no one in Claude Code):

- **session-start-welcome** (SessionStart) emits a concise visible system message once, after checking required plugin sentinels. It says the built-in tools are ready, points to `/as:tool-catalog`, optional `/as:studio` setup, and `/as:learn`, and does not rewrite the user’s first response. It records the one-time marker only after output succeeds.
- **post-write-disclaimer-check** (PostToolUse) emits JSON `{"decision": "block", "reason": …}` on stdout on findings, which surfaces the reason to Claude so it restores the disclaimer block.
- **version-check** (SessionStart) exits before any filesystem or network work unless the user explicitly enabled it through `/as:studio`. The first enabled session seeds a private local cache silently. Later sessions make at most one two-second request per 24 hours, fail silently, and notify once for each newer version. Disable it with `/as:studio updates disable`.

The deterministic preference helper lives with the owning `/as:studio` skill; it is not a hook.

To downgrade the disclaimer hook to advisory-only, replace its JSON emission with a plain `exit 0` at the finding point in the script (the finding then goes unseen).

### post-write-disclaimer-check

Checks written or edited `.md` files for the `<!-- architecture-studio:requires-disclaimer -->` marker that regulatory skills emit. If the marker is present but the canonical disclaimer block is missing (or the marker appears more than once), it emits a `block` decision telling Claude to restore the block from `rules/professional-disclaimer.md`. Marker-driven — silent on files without the marker. Edit provides no full content in its tool input, so the hook always reads the file from disk.


## Customization

Each script is a standalone bash file, portable across macOS (BSD sed/grep) and Linux. Edit to fit your workflow:

- Downgrade enforcement to advisory: replace the JSON `block` output with `exit 0`
