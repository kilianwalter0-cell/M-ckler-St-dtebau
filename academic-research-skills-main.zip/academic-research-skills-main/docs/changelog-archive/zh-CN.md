# 简体中文版本摘要（冻结于 v3.21.2）

本文件是 `README.zh-CN.md` 在 2026-09-15 之前所载的版本摘要，原封搬出、不再更新。v3.21.2 之后的版本请看英文版 [CHANGELOG.md](../../CHANGELOG.md)；`README.zh-CN.md` 只保留最近三个版本。

_This file is the frozen copy of the Simplified Chinese release summaries that `README.zh-CN.md` carried until 2026-09-15. It is not updated; later releases are in the English [CHANGELOG.md](../../CHANGELOG.md)._

---

## 版本摘要

### v3.21.2（2026-09-06）— 模型现况对齐（Fable 5.1 / GPT-6 Astra）、检查点决策来源与 CJK 标题匹配修复

> **对齐现况与决策来源，不是新能力：**v3.21.2 依据两份 2026 年 9 月的厂商 system card 对齐套件。`gpt-6-astra` 以 provisional 身份进入跨模型表（两条传输均如此），并依世代现况政策成为推荐的 OpenAI 验证模型；`gpt-5.6-sol` 保留其在 ChatGPT 订阅引用传输上的 validated 身份，本版不声称任何新的 bakeoff 结果。受限的 Codex 传输 reasoning-effort 集合新增 `ultra`。新增两道 guardrail，均为 prompt 层、由厂商文档而非 ARS 测量驱动：检查点决策来源（只有用户回合算决策；决策逐字转交子代理；风险 R11），以及供应商端监控或安全介入一律视为传输失败、永远不是判定。针对两份卡片的 harness 淘汰审计没有淘汰任何东西（0 条 prompt 文字淘汰；8 条 keep-as-debt 项目补上卡片引注）。修复：CJK 标题不再在四个索引解析器的精确标题门失败（#798），外层引号只在构成单一平衡单位时才剥除（#800）；autolink round-trip 测试明示其依赖（#801）；`check_surface_form_parity` 改为指名坏掉的环境而非 manifest；新增 skill 清单一致性 lint（#809）；R10 残余缺口去过时化（#813）；修正一行 MLA 规则（#805）。套件／pipeline → v3.21.2；deep-research → v2.12.1；academic-paper → v3.3.1；academic-paper-reviewer → v1.11.1。

### v3.21.1（2026-08-24）— 有界工作流基础、封存式 bakeoff 与传输强化

> **有明确测量才视为已测量，其余保持有界：**v3.21.1 修复 codex-cli 0.147.0 下受限的 ChatGPT 订阅引用传输，并记录首次 Promotion Bakeoff：`gpt-5.6-sol` 仅在该订阅传输上取得 validated，first-party API 路径仍为 provisional；今后的 bakeoff 则必须采用封存式预注册。本版还新增 default-off 的研究工作流 profile 基础（只有离线、确定性的 conformance；没有 pipeline hook，也未提供特定研究家族的成品 profile）、opt-in 的 inquiry-ledger alpha（`ARS_INQUIRY_LEDGER=1`），以及尚未实现、仅冻结设计的 alternative register。其行为证据保持 `NOT_RUN`，不声明可用性、恢复、创新性、正确性或研究结果收益。评审标准 registry 新增一组有来源支持、仅用于示范的 MSR 2027 exact-profile proving set；这不代表投稿期刊／会议与学科覆盖、真实作者 attest，也不是 constructive-review 证据，所需的独立人类评估仍未完成。其他变更包括对齐 `data_access_level`、合并 markdown lint 语法、登记 guard launcher 的降级路径，以及在不背书的前提下将 OrcaRouter 列为社区集成。套件／pipeline → v3.21.1；deep-research → v2.12.1；academic-paper → v3.3.1；academic-paper-reviewer → v1.11.1。

### v3.21.0（2026-08-18）— ISO/IEC 42001 精神轨：透明、可验证、可行

> **可被检验的透明：**v3.21.0 完成 ISO/IEC 42001 精神审计轨（#753–#760）。对外声明对齐证据记录，并新增四份常设文件回答用户真正想问的问题：你的安装渠道有哪些控制实际运作（`docs/CONTROL_AVAILABILITY.md`）、哪些数据离开你的机器与存放多久（`docs/DATA_FLOWS.md`）、每个 CI workflow 实际的强制力等级（`docs/ARCHITECTURE.md` §7.1）、每个机制对应哪个风险及其证据状态、残余缺口（`docs/RISK_REGISTER.md`），每份都由专属 CI lint 防漂移。`GOVERNANCE.md` 言明决策权限、cross-model 评审提供与不提供什么（error-detection control、非组织独立性）与 end-of-life 姿态；`SECURITY.md` 新增一人可运转的分级 triage 程序。这些是附 ISO/IEC 42001 信息性锚点的操作原则、不是认证声明，本版也不新增任何效果数字。套件／pipeline → v3.21.0；deep-research → v2.12.1；academic-paper → v3.3.1；academic-paper-reviewer → v1.11.1。

### v3.20.1（2026-08-15）— 契约诚实性强化与有界评估基础

> **强化并限定范围：**v3.20.1 让评审与完整性声明符合套件实际可重放的证据。Claim coverage 明确限定于已登记或词法检测的总体，语义提取完整性仍为未知；修订导致的声明强度变化必须有逐项、byte-bound 的作者处置；新的阅读标记必须声明范围且错误会明确显示；live reviewer package 固定为 `NOT_CALIBRATED`；六轴 provenance 取代二元 independence 说法。本版还加入离线、未测量的 claim-standing probe 基础、ideation-diversity blind bundle 的封闭式首轮分配闸门，以及未来 inquiry branch／alternative 的 opt-in roadmap。这些契约不证明科学结果改善、评审正确性、完整语义检测、已验证的人类身份、独立错误过程或 live provider 的效果。套件／pipeline → v3.20.1；deep-research → v2.12.1；academic-paper → v3.3.1；academic-paper-reviewer → v1.11.1。

### v3.20.0（2026-08-14）— 证据绑定的审查与修订、受限传输、可复现的评估基础

> **新增与强化：**v3.20.0 强化审查、修订、引用、涉及人的研究与投稿流程中的证据及权限边界。新增来源绑定 evidence rows、由作者控制且不排名的修订 roadmap、可重放的跨文档一致性与内容覆盖 advisory、统一审查标准、涉及人的研究权威依据与 pathway trace、确定性投稿及委员会往来 artifact、可选的跨 run adjudication 活动观察、受限的 ChatGPT 订阅引用传输、离线 claim-standing 候选 ledger，以及可选的进程隔离 PDF 文本/OCR advisory。Reviewer 与 re-review contract 加入 role-scoped scoring、evidence-before-persuasion gate，并收紧 provenance 与 transport 处理；临床报告、中文文献解析、plugin alias、Pi 与平台文档也有扩展。新 eval 资产包含 revision drift、role topology、ideation diversity、间接 prompt injection 与 tortured-phrase screening 的冻结 hermetic fixture 和 no-call envelope。除非 `CHANGELOG.md` 明确引用已保留的实测 cohort，这些仅证明 protocol 或 synthetic/offline conformance，不证明安全性、效能、准确度或行为改善。套件／pipeline → v3.20.0；deep-research → v2.12.0；academic-paper → v3.3.0；academic-paper-reviewer → v1.11.0。

### v3.19.0（2026-07-22）— 修订轮次的主张漂移防护、PDF 读取完整性预检、read-scope 诚实覆盖标记

> **新增**：三个 advisory-or-opt-in 的完整性层加一个 launcher 修复。**修订轮次主张漂移防护（#569/#570）**：一条主张强度阶梯（`is associated with < predicts < causes`，未经授权的 roadmap 项目不得静默移动）接进修订草拟与新的 advisory Phase E6，外加一支确定性的数值/引注 token 守恒检查器——两者合起来补上 #390 honest-claim 残余的认知面与 token 面（被改动的 block 内部原本没有完整性检查）。先在当前前沿模型测量 baseline（`evals/heldout/revision_claim_drift/`），机制形状出处归功 [Yila-AI/sci-ssci-skills](https://github.com/Yila-AI/sci-ssci-skills)。**PDF 读取完整性预检（#512）**：三信号的页数交叉检查，让被截断／页码错位的 PDF 读取无法产生一个看似有效的 `page` 锚点。**read_scope 诚实覆盖标记（#513）**：在人工读取台账上可选地声明诚实覆盖范围（`full_text` / `sections` / `abstract_only` / `toc_only`），让 finalizer 的引用晋升具备 read-scope 意识。**launcher watchdog 修复（#545）**：移除一个会让每次正常 PreToolUse write-scope-guard 调用卡满整个 wall-clock 上限的 pipe 停滞。套件 → v3.19.0；底层三个 skill 版本不变。

### v3.18.0（2026-07-18）— 自我改进 survey 整合

> **新增**：由 Ren et al.（2026，arXiv:2607.13104）驱动的八项质量机制——子问题范围绑定＋Phase E 范围一致性 advisory（#547）、有界化 novelty 主张＋E5 分类（#548，均 advisory-only、在 MANDATORY 检查点逐行显示）；Stage 2.5 风险分层 claim 查核（HIGH-IMPACT 全查＋随机哨兵，#549）；引用查验 gate 接通缓存层＋时效 advisory＋opt-in 实时重验（#541）；同意制跨模型评审席（五席面板一席换底座，#540）与复审裁判独立性＋Judge Record（#539）；路由/关卡措辞稳健性测试集 v0.1（#550，并补齐 reviewer skill 缺失的中文触发词）；survey 本身列为第三个 human-in-the-loop 文献锚点（#542）。另有一项独立于 survey 轨的功能：#544 SessionStart 更新提醒——plugin 安装落后 main 时提示 `/plugin update`（`ARS_UPDATE_CHECK=0` 可关闭）。`academic-pipeline` 随套件升至 v3.18.0；其余三个 skill 版本不变。

### v3.17.0（2026-07-16）— Pipeline 边界语义、跨模型交接信封、可执行 panel checker

> **修复：**收敛 #528 两个未明确定义的 pipeline 边界 — Stage 5「finalize 前一律 MANDATORY」现在只指定唯一一个 checkpoint（Stage 4.5 通过与 Stage 5 派工之间的入口闸门），Stage 6 新增终止确认词汇（`finish`/`end`/`done`/`confirm`）与明确的婉拒路径；五个 pipeline 表面现在都加上全文件 sha256 内容锁（#529），日后任何 prompt 表面漂移都会挡 CI，直到同一个 commit 更新哈希值。盲测 checkpoint 传输移到派工层（#523）— 原本 Bucket A 的 checkpoint 拥有者被要求自行执行跨模型传输，但这在 runtime Bash deny 下无法执行；现在改由派工层负责传输调用。**新增：**canonical `[CROSS-MODEL-HANDOFF v1]` 信封 + 标准化 Python 文法（#527）取代原本纯文字约束的拥有者→派工者→拥有者传输路径，把一致/分歧/格式错误结果的路由钉死在全部三个 checkpoint 拥有者上。#514 工具白名单的防漂移锁（#524，74 个 mutation test）挡住「对 agent 本体与其镜像同步修改、悄悄加回 Bash」的漂移路径。可执行的 sprint-contract panel checker（#510）从原始产出物重新算出 v3.6.2 的两层决策，并抓到多数决公式的一个转录错误。机器可读的降级注册表（#511 Part A）把套件内每个优雅降级机制都列成索引，另加引用验证闸门的 hermetic transport-fixture 集成测试（#511 Part B），对四个解析器 client 端到端跑过检入版的合成 API 响应。`academic-pipeline` 跟随套件版本至 v3.17.0；其余三个 skill 版本不变。

### v3.16.0（2026-07-12）— 模型分层、跨模型闸门强化、WP 提示语锐化

> **新增：**可选模型分层（#517）— 新 `ARS_MODEL_TIERING` 开关含两个方向（`economy` 让 13 个执行型 agent 以低于 session 模型一档派工、下限 Opus 级；`quality-boost` 让完整性闸门与最终审查面的判断型 agent 升到前沿档）；未设置时逐字节等同旧行为，冻结的 39-agent 分类由新 manifest + lint 钉死。跨模型闸门强化（#518）— 风险分层抽验（HIGH-IMPACT 参考文献在两道闸门 100% 验证）、两个不可逆决策点（设计冻结 + 最终编辑决定）的盲测分歧检查、验证模型 id 状态白名单、升格 bakeoff 协议；原规划的通用第 6 位审查者确定退役、非延期。GPT-5.6 Sol 列为暂定跨模型验证者并增设明确 reasoning-effort 控制（#515）。devCharlotte 提案的韩文触发词 + 路由边界 fixture（#452/#509）。论文写作端新增 CARS 导论修辞 + 标题设计参考文件（#500）。**变更：**WP 研究问题提示语经名词替换测试泛化到 20 壳表之外（#501）并锐化豁免条款、抓到装饰型标题壳（#505）— held-out 漏判率 0.34–0.38 → 0.094、误触 0/16 维持；审查者校准协议记载 LLM 评审偏宽方向（FARS 锚点，#484）；OpenAlex API key 认证 + 预算感知 429 处理 + arXiv ToU 对齐退避（#495/#496）。**文档：**THIRD_PARTY.md 社区目录（#497/#498）。`academic-pipeline` 跟随套件版本至 v3.16.0；其余三个 skill 版本不变。

### v3.15.0（2026-07-04）— 发版闸门强化、prompt 债务清理第二轮、防漂移锁

> 以发版纪律与质量卫生为主的版本；skill 行为无变更。**新增：**三道 CI 闸门 — CHANGELOG-covers-merges tag 前闸门（#483）、版本一致性 invariant 9-11 加 tag 时重跑闸门（#487）、把 SessionStart announce 清单钉到实际 16 个指令清单的 command-invariants 闸门（#486）— 以及两道防漂移锁：Phase Boundary enforcement 句在全部 23 个 Bucket A agent 区块逐字钉死、SETUP 跨模型示例与 canonical 型号表互相钉死（#491 → #492）。**变更：**prompt 债务清理第二轮深扫第一轮延后的 17 个 agent（#489 → #490）：修正两个 socratic_mentor 的活矛盾（过期的 15 轮劝退规则 vs 文档明载的典型 20-30 轮）、修正全仓库 29 处过期的 enforcement 状态句、修剪 7 个 agent 的 few-shot 与重复流程脚手架 — 经 4 批并行稽核 + 独立 codex 跨模型挑战验证；稽核报告在 `audits/`。**修复：**DOI 徽章改由 shields.io 提供（#482）。`academic-pipeline` 跟随套件版本至 v3.15.0；其他三个 skill 版本不变。

### v3.14.0（2026-07-02）— Claude Science 可导入性、eval comment 呈现、prompt 债务清理

> 一个以可移植性与打磨为主的 release，skill 行为无变更。**新增：** Claude Science 可导入性——marketplace manifest 显式声明 skill 路径，让无法穿越 symlink `skills/` 目录的 GitHub-API 导入器（Claude Science「Import from GitHub」、Windows checkout）能找到全部四个 skill；已在 Claude Science 端到端验证，README + SETUP 新增导入指南（#480）。eval-harness 的 PR comment 改为一行结论 + 逐任务表格、原始 JSON 折叠进 `<details>`，取代裸贴整份报告——仅显示层，gate 逻辑字节不变（#479）。**变更：** 依 2026-07 harness-retirement 审计，自四个写作面 agent 移除过期的 writing-harness scaffold（#476/#477 → #478，净 −111 行 prompt）；remind-don't-block 的 Platform Port Reminder 在 PR 新增顶层目录时提示 platform-ports 政策（#473）。**文档：** devCharlotte 母语审校的韩文 README（#469/#471）；GitHub Copilot repository instructions（#465）；建议 auto permission mode 取代 Skip Permissions（#464）。累积于 `[Unreleased]` 的 16 条积压条目（代码均在 v3.13.0 tag 前已上——diff/patch revision mode #390、submission-package verifier #394、eval gold sets #215/#216 等）并入版本记录；详见 `CHANGELOG.md`。`academic-pipeline` 随 suite 至 v3.14.0；其余三个 skill 版本不变。

### v3.13.0（2026-06-18）— Hook 可移植性、provider-agnostic 验证、guard 正确性

> 一个 minor release，强化安装／执行面并扩展跨模型范围。**修正：** 写入范围 guard 在 git-clone + symlink 安装布局下不再误挡使用者自己的 `CLAUDE.md`（#459，收掉 #448/#449 的残余一半——`CLAUDE.md` 是文档而非承载 enforcement 的档案，故移出 infra 保护清单，所有承载档案仍受保护）；Windows Python hook 可移植性 + 无 Python 时优雅降级，改由跨平台 `hooks/run_guard.sh` launcher 启动，会拒绝 0-byte 的 Microsoft Store `python3` stub 且不再洗 hook log（#454）；`draft_writer` dual-phase static union 文档化 + Windows POSIX-safe 路径匹配（#451）。**新增：** provider-agnostic 跨模型验证，接受 OpenAI 相容端点（MiMo、DeepSeek、自架）与 grounded first-party OpenAI 并存，且后者绝不被静默降级（#455）；opt-in 的 Socratic 邻近 framing probe（借自 STORM 的视角扩展，`ARS_SOCRATIC_ADJACENT_PROBE=1`，预设 OFF，纯 prose-layer——`deep-research` 2.10.0 → 2.11.0）（#461）。`academic-pipeline` 随 suite 至 v3.13.0；`academic-paper` 与 `academic-paper-reviewer` 不变。逐 issue 细节见 `CHANGELOG.md`。

### v3.12.1（2026-06-15）— 审稿回复分流模式（PR #433 整合）

> 一个 patch release，依 ARS 的模式化架构，把一份外部贡献中真正具新意的部分收进既有 skill 成为模式。**新模式：** `deep-research` `three-way-scan` —— 介于 `quick` 与 `lit-review` 之间的轻量 WHY/HOW/WHAT 论文比较分流，产出逐论文短清单加跨论文统合（`deep-research` 2.9.4 → 2.10.0）；`academic-paper` `rebuttal-audit` —— 对作者既有的 rebuttal／回复草稿，比对审稿意见做独立的咨询式 QA（逐条覆盖表 + 缺口清单 + 语气／证据／误读风险旗标），它不产生任何内容，且独立调用时明确抑制 Schema 11／Material Passport 写入／`ready_to_submit`（由带 mutation 覆盖的 `check_rebuttal_audit_guard()` lint 强制）；另含 `revision-coach` 范围扩展到反驳／不同意姿态与非期刊情境，以及 `/ars-3w` + `/ars-rebuttal-audit` 斜线指令。依输入形状路由：审稿意见加草稿 → `rebuttal-audit`；仅意见 → `revision-coach`。整合自 [@Yaobin29](https://github.com/Yaobin29) 的 [PR #433](https://github.com/Imbad0202/academic-research-skills/pull/433)。Suite 模式数 25 → 27（仍 4 个 skill）。逐 issue 细节见 `CHANGELOG.md`。

### v3.12.0（2026-06-08）— Kong 自动研究功能线：实验来源、图表保真、跨论文矛盾、部分证据拆解

> **[machine-translated]** 本条目为机器翻译，待母语 contributor 校订；以英文版 CHANGELOG 为准。

> 一个 minor release，落地 Kong et al.（2026，arXiv:2605.18661）自动研究功能线，以及部分证据陷阱的拆解工作，每项都已各自审查并 merge。**新功能：** 实验来源登录 + 宣称对实验对齐 —— 为实验支撑的宣称建立 schema-first 的证据帐本层，只做登录与对齐（学者在外部跑实验，ARS 从不执行）（#260）；图表保真 gate，查验 caption 的诠释是否从资料推得、论文是否拿该图表佐证它真正支撑的宣称（#261）；结构化的跨论文矛盾盘点，把已评估的论文对列举出来供学者确认（#262）；以及在引用判定（#213）与编辑统合（#214）两层都先做子宣称拆解再判定，于两层收敛 §F.3.2 部分证据陷阱。**引导与诠释层：** 对产报告的审稿人加上精简输出 + 抗压边界强化（#274）；同源／rubric-aware 校准的认识论注记（#273）；把检索内容的指令／资料边界订为常设原则（#367）。**负面范围：** Kong META（#255）收尾，在 `POSITIONING.md` 加「拒绝机制」段落列举 ARS 不做的五种自主机制，外加两份 Tier D 设计教训文件。**发版纪律 lint：** version-consistency 不变量 5–7（#357）与 ARCHITECTURE 元件版号稽核（#345）。另含跨模型 grounding guard（#346 / #349 / #351）、引用 gate 快取键与 rationale 上界（#359 / #360 / #361）、eval 黄金集（#250）、ACL/EMNLP 揭露重新接地（#242）等正确性修正。新增的 schema、manifest 字段与所有不变量皆为增量、向后兼容。`academic-pipeline` 随 suite 升至 v3.12.0；其余三个 skill 版号不变。逐 issue 细节见 `CHANGELOG.md`。

### v3.11.1（2026-06-06）— 出货后正确性、强化与来源修正汇整

> 一个 patch release，汇整 v3.11.0 出货后浮现的修正，每项都已各自审查并 merge：把跨模型同意 gate 扩展到 integrity-verification + collaboration-depth 路径（#322）、每笔 entry 的 OpenAlex + Crossref backfill 并行化（#138），以及横跨引用存在性 gate、v3.10 政策层、eval harness、领域证据 profile、#310 安全边界边角案例的七项正确性/强化修正（#323 / #327 / #328 / #329 / #331 / #332 / #333）—— 其中两项是 P1（#327 no-handoff 路径上的领域 profile 启动、#328 eval harness 的 per-class 门槛 gate）。无新功能、无破坏性 schema 变更。逐 issue 细节见 `CHANGELOG.md`。

### v3.11.0（2026-06-04）— 确定性引用查验 gate（#182）

> **[machine-translated]** 本条目为机器翻译，待母语 contributor 校订；以英文版 CHANGELOG 为准。

> 新增一道**确定性的引用存在性查验 gate**，独立于 LLM 同侪审查运作。每笔引用都会比对最多四个书目索引（Semantic Scholar、OpenAlex、Crossref，以及新增的 **arXiv resolver**，`scripts/arxiv_client.py`，不需 API key），把每笔引用的 `lookup_verified` 状态（`{true, false, unresolvable}`）写进统一汇整。捏造、带着查不到的 DOI/arXiv ID 的引用，因此被 lookup 侦测标示出来（在用户选用 strict 时才升级为终止），而非寄望审查 agent 注意到。这道 gate **沿用 v3.10 `terminal_policies` 的 opt-in 模型**：侦测一律执行，但 `lookup_verified == false` 的列只有在用户选用 `terminal_policies.citation_existence == strict` 时才是终止性的；默认行为是 advisory、可用 `/ars-mark-read` 认可。`false` 的定义刻意**收窄到 ID-keyed unmatched**（一次以精确 DOI/arXiv 查验、却证实查不到），因此正当但未被索引的人文 / 非英语 / 区域期刊引用会落在 `unresolvable`、永不阻挡（这是文件中载明的「精确优先于召回」取舍）。本版另含持久化 SQLite 查验 cache（`~/.cache/ars/verification.db`，90 天 TTL）搭配 `/ars-cache-invalidate` 指令、独立的 `verification_gate` API 与 `verify_passport.py` CLI，以及把 v3.9.0 污染三角验证矩阵扩成四索引（k=0..4，全属 advisory）。`academic-pipeline` 追 suite 至 v3.11.0，其余三个 skill 版号不变。规格：`docs/design/2026-05-21-v3.10-182-promote-citation-gate-spec.md`（§0 amendment + C-V6）。

### v3.10.0（2026-06-01）— 三角验证政策层、Kong 综述采纳、评测 harness、scoped-write guard

> Minor release，打包数项工作：可选用的污染三角验证 **terminal 政策层**（#127，默认引用行为与 v3.9.0 byte-equivalent）；**Kong et al. 2026 综述采纳**，包含 Rebuttal Commitment Ledger（#256/#266/#268/#269）与依学门的 domain evidence profile（#259）；**v3.10 量测基建**，通用化评测 gold set 加 ranking-lift CI gate（#184）；**scoped-write guard MVP**（#134），一个 deterministic `PreToolUse` hook，把 23 个单一 phase 的 subagent 围进各自的 phase 目录、并禁用它们的 Bash（改用 Grep/Glob 与结构化编辑工具）；`/ars-mark-read` plugin 指令（#190）加一个 broken-on-arrival 修正（#195）；简体中文 README（#185）；以及 CI 强化（#156/#155）。`academic-paper` 升至 v3.2.0、`academic-paper-reviewer` 升至 v1.10.0，反映 Commitment Ledger 与 domain profile 的新增功能；`academic-pipeline` 追 suite 至 v3.10.0。默认 skill 行为不变，除非用户选用 strict 政策模式；唯一 default-on 的改动是 #134 guard，它约束的是被围起来的 subagent，不是面向用户的产出。

### v3.9.4.2（2026-05-19）— PR #149 CI 纪律 gate post-ship hotfix（codex post-ship）

> Codex post-ship review 对 PR #149（7 道 CI 纪律 gate）抓到 4 个 P2 finding；v3.9.4.2 修齐其中 3 个。F1：`harness-retirement-monthly.yml` 补 `GH_REPO`，让调度跑能取到 repo context 给 `gh issue create`。F2：`release-cooldown.yml` 把 `PREV_TAG` 查找 filter 到 `v*` tag，避免非 release tag（如旧 plugin tag）绕过 cooldown gate。F3：`release-cooldown.yml` 加读 annotated tag subject + 接受 `hot-fix` 拼写变体（v3.9.2 在旧检测器下是 false-negative hotfix）。PR #157 follow-up：`[skip-cooldown]` override 改从 commit message 跟 annotated tag message 双处读取（self-bootstrapping fix — 本 tag 的 cooldown 绕过正好证明 F2+F3 端到端可用）。F4（test-count-monotonic 强化）被 revert，因为它 surface 了 `scripts/` package 预存问题，追踪为 #154（已由 PR #158 修复）+ 再次尝试 #155。Closes #152。Follow-ups：#155、#156。

### v3.9.4.1（2026-05-19）— v3.9.4 时序验证 post-ship hotfix（#135 codex post-ship）

> Codex post-ship review 抓到 4 个 per-task subagent reviewer 漏掉的真 bug。Hotfix 一次修齐：(1) `audit()` 把 `citation_provenance` 接到 P2 + P4，遇到 ref slug 在 provenance.yaml 是 `confidence: low` 或 `conflict` 时，验证器改发 `TEMPORAL-METADATA-MISSING` 而不是直接用 timeline 日期当算术 ground truth（spec §3.4 第一手 safety check 原本没接线）。(2) `_date_to_interval` 补齐全部 schema-valid 日期形状，包括 `YYYY-MM`（Crossref 月精度）和 `YYYY-MM-DD..YYYY-MM-DD`（interval），v3.9.4 对这两种 silently `ValueError` 跳过。(3) P4 在 ref marker 缺席时可 bind 直接 prose 日期 — 「The 2026 policy enabled the 2020 rollout」这种句现在会 trigger。(4) `citation_provenance.schema.json` `confidence:high` allOf 加 `then.required`，补 absent-property bypass 漏洞。1561 passed（+12 新测试、0 regression）。ARCHITECTURE.md 同步补齐（先前停在 v3.8.0）。

### v3.9.4（2026-05-18）— #135 时序验证层（advisory）

> Phase 4 → 5 边界添加决定性 advisory verifier，涵盖 5 种时序失效模式（P1 回顾算术、P2 时代错置引用、P3 比较基准未实体化、P4 因果倒置、P5 现在式指示语）。新 Phase 2 sibling `timeline_extraction_agent` 拥有 `phase2_investigation/timeline.yaml` + `phase2_investigation/citation_provenance.yaml`。验证脚本 `scripts/temporal_integrity_audit.py` 运行 5 道确定性 pass。M3 时序完整性铁律加入 `report_compiler_agent` + `draft_writer_agent`。M6-minimal：Crossref `issued` + pdftotext cover 第一手验证。M7-minimal：日期出处 + 比较基准实体化。M5-stub：仅用户声明的 `version_family_id`。`literature_corpus_entry`、`claim_audit_result`、`claim_intent_manifest` 零修改。`bibliography_agent` 未改动（F2 不变量）。3 个新 sidecar schema。覆盖率估计：55-70% 基准 / 含 M7 minimal 65-75%。1549 passed（+44 新测试、0 regression）。

### v3.9.3（2026-05-18）— #128 housekeeping（client utility 抽出 + resolver dedup）

> 纯 refactor + 一个 latent bug fix，从 v3.9.0 `/simplify` review backlog 结清。抽出 `scripts/_text_similarity.py`（3-way client dedup：normalize / similarity / threshold / retry 常数）+ `scripts/_passport_yaml.py`（2-way migration tool dedup：ruamel.yaml round-trip config）+ 私有 `_resolve_by_doi_then_title` helper（2-way resolver body dedup、§3.4 / §3.5 API surface 不变）。OpenAlex + Crossref 的 throttle 量测从 `time.time`（NTP 不安全）统一改用 `time.monotonic`，与 Semantic Scholar 对齐。5 个 module-level cross-import 都加 dual-path try/except（sibling-first、namespace-package fallback）保持 class identity；额外顺手修了 2 个 latent-broken 的 `import scripts.X` 路径。1505 passed（+23 新测试、0 regression）。#128 §4（OA + CR 平行化）carry-over 到 #138。

### v3.9.2（2026-05-18）— #133 phase boundary 热修

> #133 收尾（hot-fix 层）。长期架构修正以 v3.10 active conductor 在 #134 追踪。添加：CLAUDE.md routing 厘清闸（跨 phase 素材 → 以 a-d 选项厘清，不静默 dispatch）、22 个 single-phase agent 加 prompt 硬 fence（`## Phase Boundary (v3.9.2)`）、16 个 multi-phase / phase-orthogonal / cross-phase-meta agent 刻意不加 fence（诚实 framing：纯 prose placebo 会造成假性 enforce 错觉）、advisory verifier `scripts/check_pipeline_integrity.py` 事后检测 #133 pattern。Behavioral smoke test 含 cross-model spot-check（Opus 4.7 100% / Sonnet + GPT-5.5 ≥75%）。

### v3.9.1（2026-05-18）— #129 + #130 client hardening

> v3.9.0 hot-fix。包 OpenAlex / Crossref response-read 失败为 `*Unavailable`（#129）；`check_claim_audit_consistency` 对非字符串 `manifest_id` 加 guard（#130）。无 spec 变动。

### v3.9.0（2026-05-17）— #102 跨索引三角测量

> #102 收尾。v3.7.3 已完成单索引（Semantic Scholar）污染检测；v3.9.0 延伸至三索引三角测量（S2 + OpenAlex + Crossref），定位为**纯 advisory**。`contamination_signals` 添加两个 optional boolean（`openalex_unmatched`、`crossref_unmatched`）；manual-entry not-rule 对称延伸。Finalizer 加入 4-tier advisory matrix（k=0/1/2/3，计算范围为现有 `*_unmatched` 字段），v3.7.3 的 legacy `CONTAMINATED-UNMATCHED`（k=1/k_max=1、S2-only case）保留。Formatter pass-through allowlist 从 3 条延伸至 9 条；refusal rules 1-10 依 R-L3-2-E 不变。Policy layer（strict modes、hard-block tier、`venue_type` / `triangulation_policy`）依 spec §2.3 延至 v3.10。k=3 marker 为 `CONTAMINATED-TRIANGULATION-UNMATCHED`（描述可观测现象，不推断成因）。添加 3 条 firm rules：R-L3-2-C（k 计算范围为现有字段）、R-L3-2-D（不得 API 推断分类）、R-L3-2-E（refusal list 不扩充；pass-through allowlist 须与 finalizer 同步延伸）。

**迁移：** v3.7.3 corpus — 跑 `python scripts/migrate_literature_corpus_to_v3_9_0.py PATH` 补齐两个新字段。pre-v3.7.3 corpus — **先**跑 `migrate_literature_corpus_to_v3_7_3.py`，再跑 v3.9.0 迁移工具（spec §3.7 daisy-chain；v3.9.0 工具只动已有 `contamination_signals.semantic_scholar_unmatched` 的 entries）。

### v3.8.2（2026-05-17）— #118 uncited audit_tool_failure 补面

> #118 收尾。`ARS_CLAIM_AUDIT=1` 的 uncited 约束判断路径原本碰到 `JudgeInvocationError` 会静默替换成 `{"judgment": "NOT_VIOLATED"}`，把 HIGH-WARN 的 constraint check 在 transient judge 中断时直接吞掉。v3.8.2 改走新的 `uncited_audit_failures[]` aggregate，MED-WARN advisory tier 对应 cited 路径 INV-14 row，但用独立 schema 因为 `claim_audit_result.ref_slug` 必填、uncited 路径没 ref 可绑。#118 issue body 四个 option 最后选了 option 2（新 aggregate）；option 4（re-raise 并 abort 整段 audit）因会严重折损 audit coverage（特别是 judge endpoint 不稳时）被否决。

- **新 `uncited_audit_failure.schema.json` aggregate**（spec §3.6）：每笔 uncited sentence × manifest pair 一个 entry，记录 constraint judge raise `JudgeInvocationError` 的情况。Fault-class enum 与 cited 路径 INV-14 相同（`judge_timeout` / `judge_api_error` / `judge_parse_error` / `cache_corruption` / `retrieval_api_error` / `retrieval_timeout` / `retrieval_network_error`）。`rule_version: D4-c-v1-uaf-v1`。
- **UAF-INV-1..UAF-INV-6 lint**（spec §6 rule 4d）：`finding_id` 唯一性、scoped_manifest_id 跨 aggregate integrity、(M, C) pair integrity（manifest_claim_id non-null 时）、per-(sentence, manifest) dedup、rationale fault_class 前缀、与 `constraint_violations[]` cross-aggregate exclusivity。
- **Finalizer §5 MED-WARN advisory row**：annotation `[CLAIM-AUDIT-TOOL-FAILURE-UNCITED — <fault-class>]`，gate 通过（retry-next-pass 为补救手段）。Formatter REFUSE list 不变 — UAF 是 advisory。
- **Pipeline 集成**（`scripts/claim_audit_pipeline.py`）：line 1211-1224 的 swallow site 移除；`JudgeInvocationError` 改 emit UAF row + `continue` 到下个 (sentence, manifest) pair。`constraint_violations[]` 不会再被假 NOT_VIOLATED 污染。
- **Tests**：添加 18 笔（15 笔 schema/lint TSUAFUncitedAuditFailureInvariants + 3 笔 pipeline integration TP23UncitedJudgeOutageEmitsUAF）。Baseline 694 → 712 tests、0 regression。
- **Agent doc**（`academic-pipeline/agents/claim_ref_alignment_audit_agent.md`）：Output emission 表格添加第七列；Error handling 表格从 3 种 surface 扩成 4 种，添加 uncited 路径 UAF 列。

### v3.8.0（2026-05-16）— L3 Claim-Faithfulness Locator + Audit（配对 milestone）

> v3.7.3 + v3.8 端到端关闭 L3（claim-faithfulness）缺口。v3.7.3 铺 locator 基础建设（每笔引用都带三层 anchor，给未来的审计抓得到原文位置）；v3.8 在这之上加一道审计 pass，判断引用来源是否真的支撑论文的 claim，违反者在 formatter terminal hard gate 直接阻止。本次 release 也合并了从 v3.7.0 后累积的 5 个 audit-trail-shipped feature PR（#104 / #105 / #108 / #111 / #115）。

- **#103 — `claim_ref_alignment_audit_agent`**（v3.8 PR #121）：opt-in（`ARS_CLAIM_AUDIT=1`，默认 OFF）的 Stage 4→5 audit agent。对每笔抽样引用判断与原文段落是否一致，emit `claim_audit_results[]` + `claim_intent_manifests[]` + `claim_drifts[]` + `uncited_assertions[]` + `constraint_violations[]` 五个 aggregate。Finalizer 8 列 matrix 把 HIGH-WARN 类别（CLAIM-NOT-SUPPORTED / NEGATIVE-CONSTRAINT-VIOLATION / FABRICATED-REFERENCE / ANCHORLESS / CONSTRAINT-VIOLATION-UNCITED）导去 formatter REFUSE rules 6-10。Calibration runner 随 release 提供 20 条 gold set（T-C1 FNR<0.15 + FPR<0.10、T-C2 per-class、T-C3 shape integrity）。共 8 轮 dual-track review（R1 codex + Gemini 3.1-pro-preview、R2-R8 在 Gemini quota 用完后改 codex-only）；trajectory R1 4P1+2P2 → R8 0P1+4P2 ship gate。
- **v3.7.3 — Three-Layer Citation Emission + contamination signals**（PR #98）：`synthesis_agent` / `draft_writer_agent` / `report_compiler_agent` 加上 `## Three-Layer Citation Emission (v3.7.3)` H2。每个 `<!--ref:slug-->` 都带 `<!--anchor:<kind>:<value>-->`，`<kind> ∈ {quote, page, section, paragraph, none}`（quote anchor 限 25 字以内、值需 URL-encode）。`pipeline_orchestrator_agent` finalizer 升 5 cell 并加 precedence-zero NO-LOCATOR 检查。`formatter_agent` 在 hard gate 加上对 `[UNVERIFIED CITATION — NO QUOTE OR PAGE LOCATOR]` 的明确 refusal。`literature_corpus_entry.schema.json` 添加 optional 的 `contamination_signals: { preprint_post_llm_inflection, semantic_scholar_unmatched }` 对象，`bibliography_agent` 在 ingest 时计算两个信号。11 轮 review trajectory（Codex×10 + Gemini cross-model×1）收敛 22 个 finding。Spec：`docs/design/2026-05-12-ars-v3.7.3-claim-faithfulness-and-contaminated-source-spec.md`。外部动机：Zhao 等人 arXiv:2605.07723（2026-05）。
- **#108 — AI usage disclosure policy-anchor renderer**（2026-05-14）：在原本的 venue-track renderer 之外，添加 PRISMA-trAIce / ICMJE / Nature / IEEE 四条 policy-anchor disclosure 路径。
- **#111 — `slr_lineage` emission on systematic-review → academic-paper handoff**（2026-05-15）：Schema 9 添加 optional 的 boolean `slr_lineage` 字段。Producer 是 `pipeline_orchestrator_agent`（每次 handoff transition 写入），consumer 是 `disclosure` mode（读到后按 §4.3 G2 invariant 路由到 `--policy-anchor=prisma-trAIce`）。
- **#104 — README motivation：Zhao 等人 corpus-scale 证据锚点**（2026-05-15）：README + `README.zh-TW.md` 动机段以 Zhao 等人 146,932 条幻觉引用的发现作为 v3.7.x 线设计动机的证据锚点。
- **#105 — v3.7.3 contamination_signals 回填迁移工具**（2026-05-15）：`scripts/migrate_literature_corpus_to_v3_7_3.py` 对 v3.7.3 前的 passport 反向计算两个 contamination signals 并补上。
- **#115 — Semantic Scholar client 成熟度**（2026-05-15）：`scripts/semantic_scholar_client.py` 加 1 req/s throttle（检测到 `S2_API_KEY` 时降到 0.1s）、URLError 触发的 outage latch、以及 `reset_outage_latch()` 给跨 passport 的长运行批量清算用。

### v3.7.0（2026-05-05）— Claude Code Plugin 打包

> Plugin 打包升级：ARS 现可在 Claude Code CLI / VS Code / JetBrains 一行装（`/plugin marketplace add Imbad0202/academic-research-skills` + `/plugin install academic-research-skills`）。原本的 `git clone + symlink 到 ~/.claude/skills/` 安装流程不变、继续支持；双轨都是一级公民。

- **Plugin manifest 与 marketplace metadata**（Phase 1，PR #68）：`.claude-plugin/plugin.json` 声明整个 suite（4 个 skill 通过 `skills/` 目录相对 symlink 自动探索）；`.claude-plugin/marketplace.json` 注册 plugin，使单一 GitHub-hosted endpoint 同时提供 marketplace listing 与 plugin 来源。README、`README.zh-TW.md`、`docs/SETUP.md` 都加入双轨安装指引。
- **10 个 slash command** 在 `commands/ars-*.md`（Phase 2.1，PR #69）将 `MODE_REGISTRY.md` 的条目映射到 `/ars-<mode>` 触发。每个 command frontmatter 钉住模型路由：`opus` 给 `full` 与 `revision-coach`（架构与审稿解读深度），`sonnet` 给其他 8 个。任何情境不用 Haiku。
- **3 个 plugin-shipped agent** 在 `agents/*_agent.md`（Phase 2.1，PR #69）以相对 symlink 指向 `deep-research/agents/` 内 v3.6.7 已 hardened 的下游 agent：`synthesis_agent`、`research_architect_agent`、`report_compiler_agent`。底线文件名保留以对齐 `scripts/check_v3_6_7_pattern_protection.py` hard-pin 路径与 INV-3 manifest-confined Clause 1 不变式。Symlink（不复制）维持 single source of truth，避免 v3.6.7 §6 inversion sweep + INV-1/2/3 lint 已关闭的 Pattern C3 攻击面再开。
- **`model: inherit`** 加在这三个 source agent frontmatter 上。选 inherit 而非 pin `sonnet` 是为了让 Opus session 跑 ARS full pipeline 时 agent 仍是 Opus（不被降）。用户的 `~/.claude/hooks/warn-agent-no-model.sh` PreToolUse hook 在派工边界已 gate Haiku，所以 inherit 解析到的是已经没 Haiku 的模型。
- **SessionStart announce hook** 在 `hooks/hooks.json` + `scripts/announce-ars-loaded.sh`（Phase 2.2，PR #70）。Plugin 加载时，hook 把 10 个 slash command、3 个 plugin agent、token 预算指引以 `additionalContext` 注入 LLM 第一轮。`startup` 与 `clear` 拿完整 announce；`resume` 与 `compact` 只拿一行确认，避免每次 resume 都烧 context。Bash 3.2 兼容 — macOS stock `/bin/bash` 直接跑，不需 `brew install bash`。
- **Phase 2.2 范围缩减**：原本规划的 `SubagentStop → run_codex_audit.sh` codex audit hook 在 v3.7.0 被排除，因为 (a) contract gap：SubagentStop payload 没带 stage / deliverable，wrapper 必要参数无法从 hook 推出；(b) invoker 边界：`run_codex_audit.sh` lines 4–7 明禁同 session in-LLM 调用，PostToolUse 在产出 deliverable 的 LLM session 内触发。真正的 audit-hook 集成留到后续版本，等 ARS 有 stage / deliverable propagation contract 再做。详见 `docs/design/2026-04-30-ars-v3.7.0-plugin-packaging-roadmap.md` Update note 2026-05-05（Phase 2.2 scope reduction）。
- **`docs/PERFORMANCE.md` + `.zh-TW.md`** 添加「v3.7.0 Plugin agent 与模型路由」节，说明 inherit 语意与目前 3-agent scope 边界。
- **跨三个 PR 的 codex review chain**：8 轮 inline iterative review + 3 轮 fresh PR-level review，全部在 merge 前收敛到 0 个 P0/P1/P2 finding。Phase 2.2 fresh PR review 抓到一个 P2（`${CLAUDE_PLUGIN_ROOT}` 没 quote，含空白的安装路径会 break）— inline 轮次抓不到，证实「实作 review（inline）」与「contract review（fresh）」分离的价值。
- **没动的东西**：4 个 skill 目录、25 个 mode、agent prompt、schema 文件、lint contract 全不变。Plugin 打包只**添加**顶层接口（`commands/`、`agents/`、`hooks/`、`.claude-plugin/`、`skills/` symlink dir、3 个 source agent frontmatter 加 `model: inherit`）。既有 4.3k clone 安装用户完全不破。

### v3.6.8（2026-05-03）— Generator-Evaluator Contract Gate（v3.6.6 spec ship）

> 命名说明：本次发行交付 **v3.6.6 generator-evaluator contract** spec 与实作。
> v3.6.6 因项目排序晚于 v3.6.7 才落地；design doc 内仍保留 v3.6.6 内部命名作为
> contract gate 版本，suite release 标 v3.6.8 维持 CHANGELOG 单调递增。

- **Schema 13.1**（`shared/sprint_contract.schema.json`）在 Schema 13 之上加两个 `mode` enum 值（`writer_full` + `evaluator_full`）、两个新 optional top-level 字段（`pre_commitment_artifacts` writer-only、`disagreement_handling` evaluator-only）、12 条 `allOf` branch 强制 reviewer- / writer- / evaluator-conditional gate。既有 reviewer contract 在 Schema 13.1 下 byte-equivalent validate（§3.6 zero-touch promise）。
- **两个新 shipped contract template**：`shared/contracts/writer/full.json`（D1–D7、F1/F4/F2/F3/F0）+ `shared/contracts/evaluator/full.json`（D1–D5、F1/F2/F3/F6/F4/F5/F0）。Spec branch 上原是 design-time artefact，本次发行 atomically promote 为 live shipped。
- **`academic-paper full` 模式内加入 two-phase orchestration**：Phase 4 拆成 Phase 4a（writer paper-blind 预先承诺）+ Phase 4b（writer paper-visible 撰稿 + 自评）；Phase 6 拆成 Phase 6a（evaluator paper-blind 预先承诺）+ Phase 6b（evaluator paper-visible 评分 + 决策）。phase-numbered `<phase4a_output>` / `<phase6a_output>` data delimiter 沿用 v3.6.2 reviewer pattern。Lint count summary：writer 3+4 / evaluator 5+5 / reviewer 5+6（reviewer 维持 zero-touch）。
- **`academic-paper` SKILL + agent file 添加 `## v3.6.6 Generator-Evaluator Contract Protocol` 区块**（SKILL.md 101 行 + `draft_writer_agent.md` 47 行 + `peer_reviewer_agent.md` 57 行）。SKILL.md 另加 `## Known limitations` 区块承载 graceful-degradation + cross-session resume v3.6.7+ forward note。
- **Validator 扩充**：`scripts/check_sprint_contract.py` 做 SC-* mode-gating audit（SC-5 + SC-11 reviewer-only；SC-9 跨三个 mode family 各读对应字段）。validator 单元测试从 54 条增加到 71 条（4 positive + 5 schema-branch negative + 2 §3.6 reviewer regression + 6 mode-gating）。
- **Manifest CI lint**：`scripts/check_v3_6_6_ab_manifest.py` 强制 `tests/fixtures/v3.6.6-ab/manifest.yaml` 的 §6.2 manifest schema + §6.5 git-tracked invariant。`.github/workflows/spec-consistency.yml` 把 sprint contract validation loop 扩成同时跑 reviewer + writer + evaluator 三个 template directory，并加入新的 manifest CI lint 步骤。
- **A/B evidence fixture stub**（`tests/fixtures/v3.6.6-ab/`，30 个文件）：manifest + README + 6 paper-A inputs/baseline + 1 paper-C inputs/baseline + Stage 3 reviewer excerpt + 6 codex-judge baseline placeholder。真实 fixture data 在后续 commit populate。

### v3.6.7（2026-04-30）— 下游 agent pattern protection（Step 1+2）

- **三个下游 agent 收紧 13 / 18 个已知幻觉与漂移 pattern**：`synthesis_agent`（A1–A5 叙事侧）、`research_architect_agent` survey-designer 模式（B1–B5 工具侧）、`report_compiler_agent` abstract-only 模式（C1–C3 出版侧）。三个 agent prompt 各自加上 `PATTERN PROTECTION (v3.6.7)` 区块。
- **`shared/references/` 增加四份 reference 文档**：`irb_terminology_glossary.md`、`psychometric_terminology_glossary.md`、`protected_hedging_phrases.md`、`word_count_conventions.md`。protection 条款引用这些文件路径做为 operational contract。
- **跨模型 audit prompt 模板** 在 `shared/templates/codex_audit_multifile_template.md`，含七个 audit dimension 与 `report_compiler_agent` bundle 必跑的三段式 Section 4(f) 检查。任一 sub-check 失败即 P1 finding。
- **静态 lint + 29 条 mutation 测试**：`scripts/check_v3_6_7_pattern_protection.py` 强制 protection 条款存在性与 obligation phrase 形状；`scripts/test_check_v3_6_7_pattern_protection.py` 把 codex review 的 mutation 证据封存为 unit test，未来 lint 退化会在 CI 浮上来。两者都接进 `.github/workflows/spec-consistency.yml`。
- **Codex review 纪录**：七轮 `gpt-5.5` + `xhigh` 跨模型 review 收敛到 0 P1+P2 finding 才 SHIP。Step 6（orchestrator runtime hook）与 Step 8（合成 eval case）走 follow-up PR。

### v3.6.5（2026-04-27）— Material Passport `literature_corpus[]` Consumer 集成

- **Phase 1 两个文献 consumer** 接上：`deep-research/agents/bibliography_agent.md` 与 `academic-paper/agents/literature_strategist_agent.md`。当 passport 带有非空 `literature_corpus[]` 时，两者都走相同的五步 **corpus-first、search-fills-gap** 流程，并遵守相同的四条 Iron Rule（Same criteria / No silent skip / No corpus mutation / Graceful fallback on parse failure）。
- **PRE-SCREENED 可复现区块** 进 Search Strategy 报告：列出已纳入／排除／略过的 corpus entry，附 F3 zero-hit 注解与 F4a–F4f provenance 报告（针对 `obtained_via` / `obtained_at` 部分声明情境）。`final_included = pre_screened_included[] ∪ external_included[]` 维持 neutral — bibliography entry 与 literature matrix row 不挂 provenance 标签。
- **Consumer 协定参考文档** 在 `academic-pipeline/references/literature_corpus_consumers.md`，包含 PRE-SCREENED 模板、BAD/GOOD 范例、四条 Iron Rule 与 per-consumer 读取指示。
- **CI lint** `scripts/check_corpus_consumer_protocol.py` 通过 manifest 驱动的 consumer 清单（`scripts/corpus_consumer_manifest.json`）强制九条协定不变式。
- **Schema 9 caveat 退役**：`shared/handoff_schemas.md` 移除 v3.6.4「Consumer-side integration deferred to v3.6.5+」一行，改成指向 consumer 协定的 backpointer。
- 采 presence-based 启动，不变更 schema、不引入新 env flag。Parse 失败 fallback 到 external-DB-only flow，并 surface `[CORPUS PARSE FAILURE]`。`citation_compliance_agent` 的 corpus 集成延后（目标版本将于 v3.8 后再订）。
- 无破坏性变更，既有用户 adapter 不需修改。

### v3.6.4（2026-04-25）— Material Passport `literature_corpus[]` 输入端口

- **Schema 9 添加 `literature_corpus[]`** 选填字段作为用户文献的输入端口。每笔 entry 符合 `shared/contracts/passport/literature_corpus_entry.schema.json`（CSL-JSON authors / year / title / source_pointer，加上 PRIVATE 选填的 `abstract` / `user_notes`）。
- **语言中性的 adapter 契约** 放在 `academic-pipeline/references/adapters/overview.md`：任何语言写的程序都能读用户自己的 corpus source 并产出符合契约的 `passport.yaml` + `rejection_log.yaml`。Entry-level 错误 fail-soft、adapter-level 错误 fail-loud、输出顺序确定。
- **三个 reference Python adapter** 在 `scripts/adapters/`：`folder_scan.py`（文件系统的 PDF 文件夹）、`zotero.py`（Better BibTeX JSON export）、`obsidian.py`（vault frontmatter）。仅供起点参考；非 reference source 预期用户自行实作 adapter。
- **Rejection log 契约** 在 `shared/contracts/passport/rejection_log.schema.json`，采用封闭 enum 的 categorical reason 值；永远输出（无 rejection 时为空）。
- **CI 把关**：`scripts/check_literature_corpus_schema.py` 验 schemas + adapter examples；`scripts/sync_adapter_docs.py --check` 防 schema→docs drift；新 `pytest.yml` workflow 在 path-filtered 触发跑 `scripts/adapters/tests/`。
- **仅输入端口**：v3.6.4 只定义 schema 与 adapter 契约，consumer 集成到 v3.6.5 才接上 `bibliography_agent` 与 `literature_strategist_agent`。
- 无破坏性变更。

### v3.6.3（2026-04-23）— 选用式 Passport 重置边界

- **Opt-in passport 重置边界**（`ARS_PASSPORT_RESET=1`）。把每个 FULL checkpoint 提升为 context 重置边界。添加 `resume_from_passport=<hash>` 模式，让用户在新的 Claude Code session 单凭 Material Passport ledger 就恢复 pipeline，不重播先前对话。`systematic-review` 模式 flag ON 时，每个 FULL checkpoint 一律强制重置；其他模式视重置为 flag 打开后的强默认。Flag OFF 时 byte-for-byte 维持 pre-v3.6.3 行为。
- Schema 9 添加 append-only `reset_boundary[]` ledger，两种 entry kind（`kind: boundary` + `kind: resume`）。Hash 用 JSON Canonical Form + SHA-256，搭配 canonical placeholder 处理自我参照问题。选填 `pending_decision` 负责 MANDATORY 分支决策。
- 新 CI lint `scripts/check_passport_reset_contract.py`：任何提到 flag 的文件都必须指向权威协议文档。
- 协议文档：`academic-pipeline/references/passport_as_reset_boundary.md`。
- `docs/PERFORMANCE.zh-TW.md` 更新 long-running session 指引。
- 无破坏性变更，flag 默认关闭。

### v3.6.2（2026-04-23）— 审稿 Sprint Contract Hard Gate

v3.6.2 引入 Schema 13 sprint contract 与 hard-gate 编排，强制审稿人在阅读论文前先承诺评分准则。本次只动审稿端（reviewer-only first test case）；writer/evaluator 留到 v3.6.4。详见 CHANGELOG。

- **Schema 13 sprint contract**：`panel_size`、`acceptance_dimensions`、`failure_conditions`（含 `severity` 优先序 + 随 panel 变动的 `cross_reviewer_quantifier`）、`measurement_procedure`、选用 `override_ladder`、限定 `agent_amendments`。验证器：`scripts/check_sprint_contract.py`。
- **两段 hard gate**：审稿人先在「论文内容盲」Phase 1 预先承诺评分计划，Phase 2 才看到论文；Phase 1 输出包在 `<phase1_output>...</phase1_output>` 数据分隔符内，缩窄 self-injection 面。
- **合成者三步机械协议**：建构跨审稿矩阵 → 依 panel-relative quantifier + 认可表达式词汇评估每条 `failure_condition` → 用 `severity` 决优先。禁止操作清单写在 `editorial_synthesizer_agent`。
- **出货两份审稿模板**：`shared/contracts/reviewer/full.json`（panel 5）与 `shared/contracts/reviewer/methodology_focus.json`（panel 2）。`reviewer_re_review`、`reviewer_calibration`、`reviewer_guided` 三个 mode 在 schema enum 中保留，但 v3.6.2 不出 template，继续沿用 pre-v3.6.2 行为；`reviewer_quick` 完全排除于 enum 外。
- `academic-paper-reviewer` SKILL 版本：`1.8.1 → 1.9.0`。`academic-pipeline` SKILL 版本：`3.5.1 → 3.6.2`（suite-version invariant）。Suite 版本升至 `3.6.2`。
- 详见设计稿 [`docs/design/2026-04-23-ars-v3.6.2-sprint-contract-design.md`](../../docs/design/2026-04-23-ars-v3.6.2-sprint-contract-design.md) 与协定 [`academic-paper-reviewer/references/sprint_contract_protocol.md`](../../academic-paper-reviewer/references/sprint_contract_protocol.md)。

### v3.5.1（2026-04-22）— 选用式 Socratic 诚实探测

v3.5.1 添加 Socratic Mentor 的选用式诚实探测（设置 `ARS_SOCRATIC_READING_PROBE=1` 激活）。默认关闭。详见 CHANGELOG。

- **选用式阅读诚实探测**：设置 `ARS_SOCRATIC_READING_PROBE=1` 后，Socratic Mentor 在目标导向 session 中引用特定论文时，触发一次性诚实探测，请用户摘述一段文本。拒绝回答仅记录，不扣分。探测结果写入研究计划摘要，并带入 Stage 6 AI 自我反思报告。不添加 agent，不变更 schema。
- `deep-research` SKILL 版本：`2.9.0 → 2.9.1`。`academic-pipeline` SKILL 版本：`3.5.0 → 3.5.1`。Suite 版本升至 `3.5.1`。

### v3.5.0（2026-04-21）— 协作深度观察员（Collaboration Depth Observer）

- **添加 agent**：`academic-pipeline` 添加 `collaboration_depth_agent`（Agent Team 从 3 成长为 4）。每个 FULL/SLIM checkpoint 与 pipeline 完成后（Stage 6 之后）触发，依 4 维度 rubric 对用户与 AI 的协作模式评分。**纯观察建议，永不阻挡流程**。MANDATORY checkpoints（Stages 2.5 / 4.5 的学术诚信检查）**不**触发 observer，学术诚信闸门完全保留。
- **添加 rubric**：[`shared/collaboration_depth_rubric.md`](../../shared/collaboration_depth_rubric.md) v1.0。四个维度：Delegation Intensity、Cognitive Vigilance、Cognitive Reallocation、Zone Classification（Zone 1 / Zone 2 / Zone 3）。理论依据为 Wang, S., & Zhang, H. (2026). "Pedagogical partnerships with generative AI in higher education: how dual cognitive pathways paradoxically enable transformative learning." *International Journal of Educational Technology in Higher Education*, 23:11. DOI [10.1186/s41239-026-00585-x](https://doi.org/10.1186/s41239-026-00585-x)。
- **Cross-model 分歧显式标注，不默默平均**：当 `ARS_CROSS_MODEL` 设置时，observer 于两个模型同时运行；若任一维度分差 > 2 分即标记为 `cross_model_divergence`。另提供 `ARS_CROSS_MODEL_SAMPLE_INTERVAL` 调控成本。
- **Short-stage guard**：stage 内用户 turn < 5 时注入静态 `insufficient_evidence` 区块，不派发全模型 observer call。
- **反谄媚规范**：分数 ≥ 7 必须附具体对话 turn 引用；Zone 3 触发 re-audit；禁止鼓励性语言。
- `academic-pipeline` SKILL 版本：`3.3.0 → 3.4.0`。Suite 版本升至 `3.5.0`。添加 lint `scripts/check_collaboration_depth_rubric.py` 加 10 个测试。

### v3.4.0（2026-04-20）— Compliance Agent + Schema 12

- **Compliance Agent（shared）**：单一 mode-aware agent，同时跑 PRISMA-trAIce 17 项（限 SR mode）+ RAISE 四原则 + 8-role matrix。挂载既有 Stage 2.5 / 4.5 Integrity Gate；tier-based block（Mandatory → block、HR → warn、R/O → info）。非 SR 入口只跑原则、warn-only。
- **Schema 12 compliance_report** 附加到 Material Passport 的 `compliance_history[]`（append-only）。
- **三回合 user-override 阶梯**，自动注入 `disclosure_addendum` 到 manuscript。无法规避披露要求。
- **Calibration 以透明公布取代硬门槛**，与 `task_type: open-ended` 自洽。
- **Upstream freshness CI** 检测 PRISMA-trAIce 上游漂移（non-blocking）。
- **长时间 session 文档**：Material Passport 作为跨 session 续跑机制。

### v3.3.6 (2026-04-15) — README 精简 + ARCHITECTURE 文档

- 添加 `docs/ARCHITECTURE.md` 作为 pipeline 结构的单一来源（流程、矩阵、数据访问、依赖图、质量闸门、模式）。通过 PR #18 合并入 main。
- 添加 `docs/SETUP.md` / `docs/SETUP.zh-TW.md`（前置需求、API key、Pandoc/tectonic、跨模型验证、四种安装方式），以及 `docs/PERFORMANCE.md` / `docs/PERFORMANCE.zh-TW.md`（token 预算、建议 Claude Code 设置）。README 以链接取代内嵌。
- 精简 README：移除 ASCII pipeline 图与 16 项 key-feature 清单（已被 ARCHITECTURE.md 取代）；Skill 详细信息维持版本号锚点，读者跳到 ARCHITECTURE.md §3 看各 agent 名单。
- 注记：没有任何 skill 的功能变动，纯文档重构。suite version 升级至 `3.3.6`。

### v3.3.5 (2026-04-15)
- 添加 `benchmark_report.schema.json` 与 Material Passport 的 `repro_lock` 可选区块。两者都附 pattern 文档、lint、范例。首次引入正式的 Python 开发依赖清单（`requirements-dev.txt`）。

### v3.3.4 (2026-04-15) — README 更新纪录同步修补

- 同步 `README.md` 与 `README.zh-TW.md` 内嵌的 changelog 区块，补上原本缺漏的 `v3.3.3` 与 `v3.3.2` 发版摘要。
- 扩充 `scripts/check_spec_consistency.py`，之后 README changelog 如果再次漂移，CI 会直接 fail。
### v3.3.3 (2026-04-15) — Release Prep + Lint 强化

- 强化 SKILL frontmatter lint：缺少 closing `---` fence 时，现在会明确报错，不再把整份文件后半段误当成合法 YAML。
- frontmatter 若可被 YAML 解析但不是 mapping，现在会回报可读错误，而不是直接 crash。
- 修正中英文 README 中 post-publication audit showcase 链接失效的问题。
- 在 spec consistency check 补上 README 相对链接验证，之后 dead link 会直接让 CI fail。
- 将 DOCX 输出契约在文档中统一：直接产出 `.docx` 依赖 Pandoc，否则回退为 Markdown + 转换说明。
- 完成 `v3.3.3` 发版准备：suite version bump，`academic-paper` -> v3.0.2，`academic-pipeline` -> v3.2.2。

### v3.3.2 (2026-04-15) — Data Access Level + Task Type Metadata

- 所有顶层 `SKILL.md` 添加 `metadata.data_access_level`，并以 `raw`、`redacted`、`verified_only` 为强制词汇。
- 所有顶层 `SKILL.md` 添加 `metadata.task_type`，并以 `open-ended`、`outcome-gradable` 为强制词汇。
- 为两个 metadata 字段添加 lint script 与单元测试，并接到 GitHub Actions spec consistency workflow。
- 添加 `shared/ground_truth_isolation_pattern.md`，并在 `shared/handoff_schemas.md` 中补上对新词汇的说明入口。

### v3.3.1 (2026-04-14) — 规格一致性修补

- 同步 README、`.claude/CLAUDE.md`、`MODE_REGISTRY.md` 与各 `SKILL.md` 的 mode 数量与公开版本标注。
- **历史说明（已由 v3.16 取代）：**此版本已实作完整性抽样核查与盲化、分开执行的跨模型 DA critique，当时第六位 reviewer 尚在规划；该设计后来已退役，现行 full review 维持固定五席。
- 厘清 adaptive checkpoint 语意：SLIM checkpoint 仍然必须等待用户明确确认。
- 再次明确化 Stage 2.5 与 Stage 4.5 学术诚信关卡不可跳过。
- 添加轻量 spec consistency 检查与 GitHub Actions workflow，避免后续再发生文档漂移。

### v3.3 (2026-04-09) — PaperOrchestra 启发的强化

集成 [PaperOrchestra](https://arxiv.org/abs/2604.05018)（Song, Song, Pfister & Yoon, 2026, Google）的技术。

- **Semantic Scholar API 验证** — Tier 0 程序化引用存在性核查。Levenshtein >= 0.70 标题比对、DOI 不符检测、S2 ID 去重。API 不可用时优雅降级。
- **反泄露协议** — 知识隔离指令优先使用 session 内材料，缺少的内容标记 `[MATERIAL GAP]` 而非用 LLM 记忆填补。降低 Mode 5/6 失败风险。
- **VLM 图表验证**（可选）— 用视觉模型闭环检查生成图表。10 项检核清单，最多 2 轮修正。
- **准则轨迹协议** — 跨修订轮次比较 7 个维度的证据锚定判断；具有决策影响的退步触发强制 checkpoint，不计算分数差。
- **Stage 2 并行化** — 可视化与论证建构可在大纲完成后并行运行。
- 新版本：deep-research v2.8、academic-paper v3.0、academic-pipeline v3.2

### v3.2 (2026-04-09) — Lu 2026 Nature 集成

集成 Lu 等人（2026，*Nature* 651:914-919）的研究洞见——第一个通过盲审的端到端全自动 AI 研究系统。

- **7 类 AI 研究失败模式检查清单** — 在 Stage 2.5/4.5 阻断管线：检测实现错误、幻觉实验结果、取巧特征依赖、错误包装为发现、方法伪造、框架锁定。扩充现有 5 类引用幻觉分类。
- **Reviewer 校准模式**（academic-paper-reviewer v1.8）— opt-in 的 FNR/FPR/balanced accuracy 测量，用户提供 gold set。5 次集成、跨模型默认打开、session 内强制附加信心披露。
- **AI 使用披露模式**（academic-paper v2.9）— 默认期刊路径返回 `REQUIRED`、`ACTION_ONLY`、`NOT_REQUIRED` 或 `UNKNOWN` 适用性结果，并在无法渲染时显式返回类型化停止状态；政策锚点路径使用独立的锚点渲染契约。v1 涵盖 ICLR、NeurIPS、Nature、Science、ACL、EMNLP。（后续扩充：v2 数据库（#596）新增 9 个医学出版政策目标 — ICMJE、NEJM、The Lancet、JAMA、BMJ、PLOS、Frontiers，以及数据库首批两个中文政策目标：出版社级的中华护理杂志社条目和期刊级的国际眼科杂志条目。）
- **提前停止机制**（academic-pipeline v3.1）— 收敛检查 + pipeline 开始时的 token 预算透明化。
- **忠实度-原创性模式光谱** — 按 Lu 2026 Fig 1c 分类所有 3 个 skill 的模式。
- 新版本：academic-paper v2.9、academic-paper-reviewer v1.8、academic-pipeline v3.1

### v3.1.1 (2026-04-09) — 信息系统 Senior Scholars' Basket of 11

外部贡献：[@mchesbro1](https://github.com/mchesbro1) 最初提出并撰写了 IS Basket of 8 期刊清单（[Issue #5](https://github.com/Imbad0202/academic-research-skills/issues/5)）；[@cloudenochcsis](https://github.com/cloudenochcsis) 将其扩充为完整的 Senior Scholars' Basket of 11（[Issue #7](https://github.com/Imbad0202/academic-research-skills/issues/7)、[PR #8](https://github.com/Imbad0202/academic-research-skills/pull/8)）。更新 `academic-paper-reviewer/references/top_journals_by_field.md` 第 7 节，补上 *Decision Support Systems*、*Information & Management*、*Information and Organization*。数据源：[AIS Senior Scholars' List of Premier Journals](https://aisnet.org/research/seniorscholarsbasket/)。

### v3.1 (2026-04-06) — 抗 Context Rot + 认知框架 + 精简尺寸

灵感来自 [aspi6246/Claude-Code-Skills-for-Academics](https://github.com/aspi6246/Claude-Code-Skills-for-Academics)。

**Wave 1：抗 Context Rot 锚定**
- 4 个 skill 共 29 条 Anti-Patterns（每个 7-8 条，表格含「为何失败」+「正确行为」）
- 22 个 IRON RULE 标记，确保长对话中关键规则不被遗忘
- 审查者只读约束（reviewer 不可修改论文原稿）

**Wave 2：追溯性 + 认知框架 + 中途强化**
- R&R 追溯矩阵（Schema 11）：Re-Review 添加「作者主张」+「已验证？」字段，独立核实修订主张
- 3 个认知框架 reference 文件，教 agent「如何思考」而非只是「做什么」：
  - 论证与推理框架（Toulmin 模型、Bradford Hill 因果推理、最佳解释推论、认知状态分类）
  - 评审质量思维框架（三镜头法、常见审查陷阱、校准问题）
  - 写作判断力框架（清晰度测试、读者旅程、学科语态、修订决策矩阵）
- 中途强化机制：每次 stage 转换注入对应 IRON RULE + Anti-Pattern 提醒
- FULL checkpoint 前的 5 题自我检查（引用完整性、谄媚让步、逐项准则退步、范围纪律、完整性；目前不宣称已有 typed trajectory）

**Wave 3：精简 Skill 尺寸**
- SKILL.md 总大小从 142KB 降至 85KB（-40%），详细协议移至 `references/` 按需加载
- 添加 ~15 个 reference 文件（re-review protocol、guided mode、systematic review、process summary 等）
- 所有 IRON RULE 保留在 SKILL.md；详细内容按需加载
- 新版本：deep-research v2.7、academic-paper v2.8、academic-paper-reviewer v1.7、academic-pipeline v3.0

### v3.0 (2026-04-03) — 反谄媚 + 意图检测 + 跨模型验证 + AI 自我反思
- **魔鬼代言人让步门槛**（deep-research + academic-paper-reviewer）：反驳必须评分 1-5。≥4 才允许让步。不允许连续让步。让步率追踪。框架锁定检测。
- **攻击强度保持**（academic-paper-reviewer）：DA 不因被反驳而软化。反驳评估协议含偏移检测。
- **意图检测层**（deep-research socratic）：检测探索型 vs. 目标型。探索模式停用自动收敛，最大轮数提升至 60。每 5 轮重新评估。
- **对话健康度指针**（deep-research socratic）：每 5 轮后台自检，检测持续同意、回避冲突、过早收敛。检测到模式时自动注入挑战性问题。
- **历史版跨模型验证条目（已由 v3.16 取代）：**此版本加入完整性抽样跨模型核查与盲化、分开执行的 DA critique；当时规划的第六位 reviewer 后来已退役。现行跨模型评审是在固定五席中替换一席的模型基座；最新同意与路由契约见 `shared/cross_model_verification.md`。
- **AI 自我反思报告**（academic-pipeline Stage 6）：Pipeline 结束后 AI 行为自评——DA 让步率、健康警报、谄媚风险评级（LOW/MEDIUM/HIGH）、框架锁定事件。
- 来源：四轮辩证实验中发现 DA 让步太快、苏格拉底模式过早收敛、整个辩论锁定在人类设置的框架中。
- 版本：deep-research v2.5、academic-paper-reviewer v1.5、academic-pipeline v2.8

### v2.9.1 (2026-04-03) — Skill Metadata
- 为 4 个 SKILL.md 加入 `status: active` 和 `related_skills` 交叉引用
- 支持 skill 探索工具及跨技能导航

### v2.9 (2026-03-27) — 风格校准 + 写作质量检查
- **风格校准**（academic-paper intake Step 10，可选）：提供 3+ 篇过去论文，pipeline 会学习你的写作风格 — 句子节奏、词汇偏好、引用集成方式。写作时作为软性指引；学科规范永远优先。优先级系统：学科规范（硬性）> 期刊惯例（强）> 个人风格（软性）。见 `shared/style_calibration_protocol.md`
- **写作质量检查**（`academic-paper/references/writing_quality_check.md`）：写作质量 checklist，于初稿自我审查时套用。5 大类：AI 高频词汇警告（25 个词）、标点模式控制（em dash ≤3）、开头废话检测、结构模式警告（三项枚举强迫症、均匀段落、同义词循环）、句子长度变化检查。这是好写作规则 — 不是逃避检测
- **Style Profile** 通过 academic-pipeline Material Passport 携带（`shared/handoff_schemas.md` Schema 10）
- **deep-research** report compiler 也可选地消费这两个功能
- 版本：academic-paper v2.5、deep-research v2.4、academic-pipeline v2.7

### v2.8 (2026-03-22) — SCR Loop Phase 1：State-Challenge-Reflect 反思机制
- **Socratic Mentor Agent**（deep-research + academic-paper）：集成 SCR（表态-挑战-反思）协议
  - **Commitment Gate**：在每个层级/章节转换前收集用户预测，再呈现数据
  - **Certainty-Triggered Contradiction**：检测高信心语句（「显然」「毫无疑问」），自动引入反面观点
  - **Adaptive Intensity**：追踪 commitment 准确率，动态调整挑战频率
  - **Self-Calibration Signal (S5)**：新收敛信号，追踪用户在对话中是否展现自我校准能力
  - **SCR Switch**：用户可随时说「跳过预测」关闭 SCR，或「恢复预测」重新打开，苏格拉底式提问不受影响
- `deep-research/references/socratic_questioning_framework.md`：添加 SCR Overlay Protocol，映射 SCR 三阶段到苏格拉底功能
- 添加 `CHANGELOG.md`

### v2.7 (2026-03-09) — 学术诚信验证 v2.0：反幻觉全面改版
- **integrity_verification_agent v2.0**：Anti-Hallucination Mandate（禁止靠 AI 记忆验证）、消除灰色地带分类（仅 VERIFIED/NOT_FOUND/MISMATCH）、强制 WebSearch audit trail、Stage 4.5 独立全面验证、Gray-Zone Prevention Rule
- **已知引用幻觉 Pattern**：5 类分类法（TF/PAC/IH/PH/SH，来自 GPTZero × NeurIPS 2025 研究）、5 种复合欺骗模式、实战案例、文献统计
- **出版后审计**：对全部 68 篇引用做 WebSearch 逐一验证，发现 21 篇有问题（31% 错误率），证明外部核查的必要性
- **论文修正**：移除 4 篇捏造引用、修正 6 篇作者错误、修正 7 篇书目细节、修正 2 篇格式问题

### v2.6.2 (2026-03-09) — 意图匹配模式启动
- **deep-research**：苏格拉底模式改为**意图匹配**启动，取代关键字比对。支持任何语言 — 检测含义（如「用户想要引导式思考」）而非比对特定字符串。
- **academic-paper**：Plan 模式改为**意图匹配**启动。检测意图信号如「用户不确定如何开始」「用户想要逐步引导」，不限语言。
- 两个模式添加**默认规则**：当意图模糊时，偏好 `socratic`/`plan` 而非 `full` — 先引导比较安全。
- 双层架构：Layer 1（skill 启动）用双语关键字提高匹配信心；Layer 2（mode 路由）用语言无关的意图信号。

### v2.6.1 (2026-03-09) — 双语触发关键字
- **deep-research**：添加繁体中文触发关键字，涵盖一般启动和苏格拉底模式。
- **academic-paper**：添加繁体中文触发关键字及 Plan Mode 触发区块。
- 两份 mode selection guide 加入双语范例及中文专属误选情境。

### v2.6 / v2.4 / v1.4 (2026-03-08) — 15+ 项改进
- **deep-research v2.3**：添加系统性文献回顾 / PRISMA 模式（第 7 模式）；3 个新 agent（risk_of_bias、meta_analysis、monitoring）；PRISMA 协议/报告模板；苏格拉底收敛准则（4 信号 + 自动结束）；快速模式选择指南
- **academic-paper v2.4**：2 个新 agent（visualization、revision_coach）；修订追踪模板含 4 种状态；引用格式转换（APA↔Chicago↔MLA↔IEEE↔Vancouver）；统计可视化标准；苏格拉底收敛准则；修订复原范例；**LaTeX 输出强化** — 强制 `apa7` document class、`ragged2e` + `etoolbox` 文本对齐修正、表格栏宽公式、双语摘要置中、标准字体集（Times New Roman + 思源宋体 VF + Courier New）、仅 tectonic 编译 PDF
- **academic-paper-reviewer v1.4（历史）**：当时引入的数值量表与固定决策映射现已停用；当前采用逐准则叙事判断，live review 一律为 `NOT_CALIBRATED`，measured profile 尚未接入 live review；快速模式选择指南保留。
- **academic-pipeline v2.6**：自适应 checkpoint（FULL/SLIM/MANDATORY）；Phase E 主张验证；材料护照（Material Passport）支持中途进入；跨 skill 模式顾问（14 情境）；团队协作协议；强化衔接 schema（9 个含验证规则）；学术诚信审查失败复原范例

### v2.4 / v1.3 (2026-03-08)
- **academic-pipeline v2.4**：添加 Stage 6 过程记录 — 自动生成结构化论文创建过程记录（MD → LaTeX → PDF，中英双语）；必含最后一章：**协作质量评估**，6 个维度各计 1–100 分（方向设置、智识贡献、质量把关、迭代纪律、委派效率、后设学习），含诚实回馈与改进建议；pipeline 从 9 阶段扩展为 10 阶段

### v2.3 / v1.3 (2026-03-08)
- **academic-pipeline v2.3**：Stage 5 定稿阶段现在会先询问格式风格（APA 7.0 / Chicago / IEEE）；PDF 必须从 LaTeX 经 `tectonic` 编译（禁止 HTML-to-PDF）；APA 7.0 使用 `apa7` document class（`man` 模式）+ XeCJK 支持中英双语；字体：Times New Roman + 思源宋体 VF + Courier New

### v2.2 / v1.3 (2025-03-05)
- **跨 Agent 质量对齐**：统一定义（同行评审、时效规则、CRITICAL 严重度、来源分级）横跨所有 agent
- **deep-research v2.2**：synthesis 反模式、苏格拉底自动结束条件、DOI+WebSearch 验证、强化伦理与学术诚信审查、模式转换矩阵
- **academic-paper v2.2**：4 级论证强度评分、抄袭筛查、2 个新失败路径（F11 退稿复活、F12 研讨会转期刊）、Plan→Full 模式转换
- **academic-paper-reviewer v1.3**：DA vs R3 角色边界、CRITICAL 判定标准、共识分类（4/3/SPLIT/DA-CRITICAL）、信心分数加权、亚洲与区域期刊参考
- **academic-pipeline v2.2**：checkpoint 确认语意、模式切换矩阵、技能失败降级策略、状态所有权协议、素材版本控制

### v2.0.1 (2026-03)
- **精简 4 个 SKILL.md**（-371 行, -16.5%）：移除跨 skill 重复、内嵌模板改为文件引用、冗余路由表、重复模式选择区块
- 修复 academic-paper 与 academic-pipeline 之间修订循环上限的矛盾

### v2.0 (2026-02)
- **academic-pipeline v2.0**：5→9 阶段、强制学术诚信验证、两阶段审查、苏格拉底修订指导、可复现性保证
- **academic-paper-reviewer v1.1**：+魔鬼代言人审查者（第 7 agent）、+re-review 模式（验收）、+审后苏格拉底指导
- 添加 agent：`integrity_verification_agent` — 100% 引用/数据验证，含审计轨迹
- 添加 agent：`devils_advocate_reviewer_agent` — 8 维度论点挑战
- 输出顺序：MD → Pandoc 可用时产出 DOCX（否则提供说明）→ 询问 LaTeX → 确认 → PDF

### v1.0 (2026-02)
- 初版发布
- deep-research v2.0（10 agents、6 模式含 socratic）
- academic-paper v2.0（10 agents、8 模式含 plan）
- academic-paper-reviewer v1.0（6 agents、4 模式含 guided）
- academic-pipeline v1.0（调度器）
